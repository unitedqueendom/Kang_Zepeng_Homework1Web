console.log("JS file is linked");

let firstName = "Marco";

let age = 40;
console.log(`Hello ${firstName}
  Deluca`); 
console.log("Hello + firstName");
